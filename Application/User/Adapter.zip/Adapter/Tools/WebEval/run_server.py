"""
Standalone server launcher that imports app.py and registers extra API routes.
Use this instead of running app.py directly to get keyword recording + training.
"""
import json
import os
import re
import struct
import subprocess
import sys
import threading
import wave
from pathlib import Path

import numpy as np

import app as _app_module

app = _app_module.app

# Keep runtime data/model paths aligned with app.py and the embedded project.
DATASET_DIR = _app_module.DATASET_DIR
MODEL_DIR = _app_module.MODEL_DIR
MODEL_PATH = _app_module.MODEL_PATH
CALIB_PATH = MODEL_DIR / "my_kws_calib.npz"

# WebEval -> Tools -> Adapter -> User -> Application -> xos_ai -> stm32f412
_STM32_ROOT = Path(_app_module.BASE_DIR).parent.parent.parent.parent.parent.parent
_COMPILER_ROOT = _STM32_ROOT / "rl_sdk" / "minerva" / "compiler"

# Compiler/training scripts
TRAIN_SCRIPT = _COMPILER_ROOT / "train_kws_npz.py"
COMPILE_SCRIPT = _COMPILER_ROOT / "minerva_compile.py"
KEY_PATH = _COMPILER_ROOT / "key.bin"

# Ensure directories exist
DATASET_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

_training_lock = threading.Lock()
_training_status = {"running": False, "message": "", "error": None}

# Path to model_data.js (same dir as run_server.py / app.py)
_MODEL_DATA_JS = Path(_app_module.BASE_DIR) / "model_data.js"


def _generate_model_data_js(model_path: Path):
    """Convert .npz model to model_data.js for frontend JS inference."""
    data = np.load(model_path, allow_pickle=True)
    result = {
        "labels": [str(x) for x in data["labels"].tolist()],
        "w0": data["layer_0_w"].astype(np.float32).tolist(),
        "b0": data["layer_0_b"].astype(np.float32).tolist(),
        "w1": data["layer_1_w"].astype(np.float32).tolist(),
        "b1": data["layer_1_b"].astype(np.float32).tolist(),
        "w2": data["layer_2_w"].astype(np.float32).tolist(),
        "b2": data["layer_2_b"].astype(np.float32).tolist(),
    }
    js_content = "window.MODEL_DATA = " + json.dumps(result) + ";\n"
    _MODEL_DATA_JS.write_text(js_content, encoding="utf-8")
    print(f"[WebEval] Updated {_MODEL_DATA_JS} with labels: {result['labels']}")
    return True


def _bootstrap_unknown_samples(rng_seed: int = 42):
    """
    Generate diverse "unknown" training samples so the model learns
    what is NOT a keyword. Without this, the model only sees corrupted
    keyword audio as unknown, causing near-100% false positives.

    Strategies:
      - White / pink-ish / band-limited noise bursts
      - Random sine-chirp "speech-like" nonsense
      - Scrambled/shuffled keyword audio (destroys temporal structure)
      - Mixed overlapping keyword fragments
    """
    UNKNOWN_DIR = DATASET_DIR / "unknown"
    # Clear old auto-generated samples
    for old in UNKNOWN_DIR.glob("auto_*.wav"):
        old.unlink()
    UNKNOWN_DIR.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(rng_seed)
    sr = 48000
    gen_count = 0

    # Collect keyword PCM for scrambling
    kw_pcms = []
    for kw_dir in DATASET_DIR.iterdir():
        if not kw_dir.is_dir() or kw_dir.name.lower() == "unknown":
            continue
        for wav_path in kw_dir.glob("*.wav"):
            try:
                with wave.open(str(wav_path), "rb") as wf:
                    raw = wf.readframes(wf.getnframes())
                pcm = np.frombuffer(raw, dtype="<i2").astype(np.float32)
                if len(pcm) > 480:
                    kw_pcms.append(pcm)
            except Exception:
                pass

    def _write_wav(pcm_i16: np.ndarray, name: str):
        nonlocal gen_count
        out = UNKNOWN_DIR / name
        with wave.open(str(out), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(pcm_i16.astype(np.int16).tobytes())
        gen_count += 1

    # 1. Pure noise variants (different colors)
    for i in range(6):
        dur = rng.integers(16000, 48000)
        noise_type = rng.integers(0, 3)
        if noise_type == 0:  # white
            pcm = rng.normal(0, 800, dur).astype(np.float32)
        elif noise_type == 1:  # pink-ish: low-pass via moving average
            raw = rng.normal(0, 1200, dur + 4).astype(np.float32)
            pcm = np.convolve(raw, np.ones(5) / 5, mode="valid")[:dur]
        else:  # band-limited: 300-3400 Hz
            raw = rng.normal(0, 1500, dur).astype(np.float32)
            from numpy.fft import rfft, irfft
            spec = rfft(raw)
            freqs = np.fft.rfftfreq(dur, 1 / sr)
            spec[(freqs < 300) | (freqs > 3400)] = 0
            pcm = irfft(spec, n=dur).astype(np.float32)
        pcm = np.clip(pcm * rng.uniform(0.6, 1.0), -32768, 32767)
        _write_wav(pcm, f"auto_noise_{i:03d}.wav")

    # 2. Sine-chirp speech-like nonsense
    for i in range(4):
        dur = rng.integers(12000, 40000)
        t = np.arange(dur, dtype=np.float32) / sr
        n_tones = rng.integers(3, 7)
        pcm = np.zeros(dur, dtype=np.float32)
        for _ in range(n_tones):
            f0 = rng.uniform(200, 2000)
            f1 = f0 * rng.uniform(0.7, 1.4)
            env_len = dur // n_tones
            pos = rng.integers(0, max(1, dur - env_len))
            env = np.hanning(env_len * 2)[:env_len].astype(np.float32)
            if pos + env_len > dur:
                env = env[:dur - pos]
            freq = np.linspace(f0, f1, len(env))
            phase = np.cumsum(freq) / sr * 2 * np.pi
            pcm[pos:pos + len(env)] += np.sin(phase) * env * 0.3
        pcm = np.clip(pcm * rng.uniform(600, 1200), -32768, 32767)
        _write_wav(pcm, f"auto_synth_{i:03d}.wav")

    # 3. Scrambled keyword audio (destroys word identity, keeps speech texture)
    for i, pcm_kw in enumerate(kw_pcms[:5]):
        dur = min(len(pcm_kw), sr)
        seg = pcm_kw[:dur].copy()
        # Shuffle 10ms chunks
        chunk_sz = int(sr * 0.01)
        n_chunks = len(seg) // chunk_sz
        if n_chunks < 4:
            continue
        chunks = [seg[j * chunk_sz:(j + 1) * chunk_sz] for j in range(n_chunks)]
        rng.shuffle(chunks)
        scrambled = np.concatenate(chunks)
        scrambled = scrambled * rng.uniform(0.7, 1.3)
        scrambled = np.clip(scrambled, -32768, 32767)
        _write_wav(scrambled, f"auto_scramble_{i:03d}.wav")

    # 4. Overlapping keyword fragments (mixed speech nonsense)
    if len(kw_pcms) >= 2:
        for i in range(min(3, len(kw_pcms) - 1)):
            p1 = kw_pcms[i][:sr]
            p2 = kw_pcms[(i + 1) % len(kw_pcms)][:sr]
            min_len = min(len(p1), len(p2))
            start_offset = rng.integers(0, max(1, min_len // 4))
            mixed = np.zeros(min_len + start_offset, dtype=np.float32)
            mixed[:min_len] = p1[:min_len] * rng.uniform(0.4, 0.7)
            mixed[start_offset:start_offset + min_len] += p2[:min_len] * rng.uniform(0.4, 0.7)
            mixed = np.clip(mixed, -32768, 32767)
            _write_wav(mixed, f"auto_mix_{i:03d}.wav")

    # 5. Silence with occasional clicks (ambient-like)
    for i in range(2):
        dur = rng.integers(20000, sr)
        pcm = np.zeros(dur, dtype=np.float32)
        n_clicks = rng.integers(2, 8)
        for _ in range(n_clicks):
            pos = rng.integers(0, max(1, dur - 200))
            pcm[pos:pos + rng.integers(5, 80)] += rng.uniform(-2000, 2000)
        pcm += rng.normal(0, 30, dur).astype(np.float32)
        pcm = np.clip(pcm, -32768, 32767)
        _write_wav(pcm, f"auto_ambient_{i:03d}.wav")

    # 6. Pure silence (varying lengths) -- critical: model must learn silence = unknown
    for i in range(4):
        dur = rng.integers(16000, sr)
        pcm = np.zeros(dur, dtype=np.float32)
        _write_wav(pcm, f"auto_silence_{i:03d}.wav")

    # 7. Near-silence (tiny ambient hiss, < 5 LSB)
    for i in range(3):
        dur = rng.integers(16000, sr)
        pcm = (rng.normal(0, 3, dur)).astype(np.float32)
        pcm = np.clip(pcm, -32768, 32767)
        _write_wav(pcm, f"auto_quiet_{i:03d}.wav")

    print(f"[WebEval] Bootstrapped {gen_count} diverse unknown samples in {UNKNOWN_DIR}")
    return gen_count


def sanitize_keyword(name: str) -> str:
    s = name.strip()
    if not s:
        return ""
    s = re.sub(r'[\\/:*?"<>|]', '_', s)
    s = re.sub(r'\s+', '_', s)
    s = re.sub(r'[^a-zA-Z0-9_\u4e00-\u9fff]', '', s)
    return s[:32]


# ── API routes ────────────────────────────────────────────────────────────────

@app.get("/api/keywords")
def list_keywords():
    from flask import jsonify
    keywords = []
    if DATASET_DIR.exists():
        for d in sorted(DATASET_DIR.iterdir()):
            if d.is_dir():
                wavs = sorted(d.glob("*.wav"))
                keywords.append({
                    "name": d.name,
                    "samples": len(wavs),
                    "files": [w.name for w in wavs],
                })
    return jsonify({"keywords": keywords})


@app.get("/api/train_status")
def train_status():
    from flask import jsonify
    return jsonify(_training_status)


@app.post("/api/record")
def record_sample():
    from flask import jsonify, request
    keyword = request.form.get("keyword", "").strip()
    safe = sanitize_keyword(keyword)
    if not safe:
        return jsonify({"error": "invalid keyword name"}), 400

    if "audio" not in request.files:
        return jsonify({"error": "missing audio file"}), 400

    kw_dir = DATASET_DIR / safe
    kw_dir.mkdir(parents=True, exist_ok=True)

    existing = sorted(kw_dir.glob("seg_*.wav"))
    next_idx = 0
    if existing:
        nums = []
        for p in existing:
            try:
                nums.append(int(p.stem.split("_")[-1]))
            except ValueError:
                pass
        next_idx = max(nums) + 1 if nums else len(existing)

    out_path = kw_dir / f"seg_{next_idx:03d}.wav"
    audio = request.files["audio"]
    audio.save(str(out_path))

    total = len(sorted(kw_dir.glob("*.wav")))
    print(f"[WebEval] Recorded {out_path.name} for keyword '{safe}' (total: {total})")
    return jsonify({
        "ok": True,
        "keyword": safe,
        "file": out_path.name,
        "total_samples": total,
    })


@app.post("/api/delete_keyword")
def delete_keyword():
    from flask import jsonify, request
    keyword = request.form.get("keyword", "").strip()
    safe = sanitize_keyword(keyword)
    if not safe:
        return jsonify({"error": "invalid keyword name"}), 400
    kw_dir = DATASET_DIR / safe
    if not kw_dir.exists():
        return jsonify({"error": "keyword not found"}), 404
    import shutil
    shutil.rmtree(str(kw_dir))
    print(f"[WebEval] Deleted keyword '{safe}' and all its samples")
    return jsonify({"ok": True, "keyword": safe})


@app.post("/api/delete_sample")
def delete_sample():
    from flask import jsonify, request
    keyword = request.form.get("keyword", "").strip()
    filename = request.form.get("file", "").strip()
    safe = sanitize_keyword(keyword)
    if not safe or not filename:
        return jsonify({"error": "invalid params"}), 400
    filepath = DATASET_DIR / safe / filename
    if not filepath.exists():
        return jsonify({"error": "file not found"}), 404
    filepath.unlink()
    print(f"[WebEval] Deleted sample {filename} from '{safe}'")
    return jsonify({"ok": True, "keyword": safe, "file": filename})


@app.post("/api/compile")
def trigger_compile():
    """Compile existing .npz model to STM32 embedded weights (C headers)."""
    from flask import jsonify

    if not MODEL_PATH.exists():
        return jsonify({"error": "No trained model found. Train first."}), 404

    if not _training_lock.acquire(blocking=False):
        return jsonify({"error": "training/compilation already in progress"}), 409

    _training_status["running"] = True
    _training_status["message"] = "Compiling STM32 weights..."
    _training_status["error"] = None

    def _run_compile():
        try:
            if not KEY_PATH.exists():
                _training_status["message"] = "Generating encryption key..."
                KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
                KEY_PATH.write_bytes(os.urandom(32))
                print(f"[WebEval] Generated key at {KEY_PATH}")

            print("[WebEval] Running minerva_compile.py ...")
            cmd = [sys.executable, str(COMPILE_SCRIPT),
                   str(MODEL_PATH),
                   "--key", str(KEY_PATH),
                   "--target", "stm32f4",
                   "--out-dir", str(MODEL_DIR)]
            if CALIB_PATH.exists():
                cmd.insert(5, "--calibrate")
                cmd.insert(6, str(CALIB_PATH))
            else:
                print("[WebEval] No calibration file, compiling without PTQ calibration")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            print("[WebEval] compile stdout:", result.stdout)
            if result.returncode != 0:
                print("[WebEval] compile stderr:", result.stderr)
                _training_status["error"] = f"Compilation failed: {result.stderr[:500]}"
                return

            # List generated files
            generated = []
            for fname in ["weights.c", "weights.h", "labels.h", "mnv_model_config.h"]:
                fp = MODEL_DIR / fname
                if fp.exists():
                    generated.append({"name": fname, "size": fp.stat().st_size})

            _training_status["message"] = (
                f"Done. Generated {len(generated)} files in {MODEL_DIR}"
            )
            print(f"[WebEval] Compilation complete. Files: {[g['name'] for g in generated]}")

        except subprocess.TimeoutExpired:
            _training_status["error"] = "Compilation timed out (2 min limit)"
        except Exception as e:
            _training_status["error"] = f"Compilation error: {str(e)}"
            print(f"[WebEval] Compilation exception: {e}")
        finally:
            _training_status["running"] = False
            _training_lock.release()

    threading.Thread(target=_run_compile, daemon=True).start()
    return jsonify({"ok": True, "message": "Compilation started in background"})


@app.post("/api/train")
def trigger_train():
    from flask import jsonify, request

    if not _training_lock.acquire(blocking=False):
        return jsonify({"error": "training already in progress"}), 409

    _training_status["running"] = True
    _training_status["message"] = "Starting training..."
    _training_status["error"] = None

    def _run_training():
        try:
            keyword_dirs = [d for d in DATASET_DIR.iterdir() if d.is_dir()]
            total_samples = sum(len(list(d.glob("*.wav"))) for d in keyword_dirs)
            if total_samples < 6:
                _training_status["error"] = f"Too few samples ({total_samples}). Need at least 6."
                return

            if not KEY_PATH.exists():
                _training_status["message"] = "Generating encryption key..."
                KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
                KEY_PATH.write_bytes(os.urandom(32))
                print(f"[WebEval] Generated key at {KEY_PATH}")

            MODEL_DIR.mkdir(parents=True, exist_ok=True)

            _training_status["message"] = "Generating diverse unknown samples..."
            try:
                n_unknown = _bootstrap_unknown_samples()
                print(f"[WebEval] Generated {n_unknown} bootstrapped unknown samples")
            except Exception as e:
                print(f"[WebEval] WARNING: unknown bootstrap failed: {e}")

            _training_status["message"] = "Training model..."
            print("[WebEval] Running train_kws_npz.py ...")
            result = subprocess.run(
                [sys.executable, str(TRAIN_SCRIPT),
                 "--data-dir", str(DATASET_DIR),
                 "--out-model", str(MODEL_PATH),
                 "--out-calib", str(CALIB_PATH),
                 "--epochs", "200"],
                capture_output=True, text=True, timeout=300,
            )
            print("[WebEval] train stdout:", result.stdout)
            if result.returncode != 0:
                print("[WebEval] train stderr:", result.stderr)
                _training_status["error"] = f"Training failed: {result.stderr[:500]}"
                return

            _training_status["message"] = "Compiling model..."
            print("[WebEval] Running minerva_compile.py ...")
            cmd2 = [sys.executable, str(COMPILE_SCRIPT),
                    str(MODEL_PATH),
                    "--key", str(KEY_PATH),
                    "--target", "stm32f4",
                    "--out-dir", str(MODEL_DIR)]
            if CALIB_PATH.exists():
                cmd2.insert(5, "--calibrate")
                cmd2.insert(6, str(CALIB_PATH))
            result2 = subprocess.run(cmd2, capture_output=True, text=True, timeout=120)
            print("[WebEval] compile stdout:", result2.stdout)
            if result2.returncode != 0:
                print("[WebEval] compile stderr:", result2.stderr)
                _training_status["error"] = f"Compilation failed: {result2.stderr[:500]}"
                return

            _training_status["message"] = "Updating frontend model_data.js..."
            try:
                _generate_model_data_js(MODEL_PATH)
            except Exception as e:
                print(f"[WebEval] WARNING: Failed to update model_data.js: {e}")

            _training_status["message"] = "Reloading model..."
            try:
                _app_module.runner = _app_module.ModelRunner(MODEL_PATH)
                print(f"[WebEval] Model reloaded, labels: {_app_module.runner.labels}")
            except Exception as e:
                _training_status["error"] = f"Model reload failed: {e}"
                return

            _training_status["message"] = f"Done. Model trained with labels: {_app_module.runner.labels}"
            print(f"[WebEval] Training complete. Labels: {_app_module.runner.labels}")

        except subprocess.TimeoutExpired:
            _training_status["error"] = "Training timed out (5 min limit)"
        except Exception as e:
            _training_status["error"] = f"Training error: {str(e)}"
            print(f"[WebEval] Training exception: {e}")
        finally:
            _training_status["running"] = False
            _training_lock.release()

    threading.Thread(target=_run_training, daemon=True).start()
    return jsonify({"ok": True, "message": "Training started in background"})


if __name__ == "__main__":
    print(f"[WebEval] Paths:")
    print(f"  DATASET_DIR = {DATASET_DIR}")
    print(f"  MODEL_DIR   = {MODEL_DIR}")
    print(f"  MODEL_PATH  = {MODEL_PATH}")
    print(f"  TRAIN_SCRIPT= {TRAIN_SCRIPT}")
    print(f"  COMPILE_SCRIPT={COMPILE_SCRIPT}")

    # Re-initialize runner with correct MODEL_PATH
    if MODEL_PATH.exists():
        try:
            _app_module.runner = _app_module.ModelRunner(MODEL_PATH)
            print(f"[WebEval] Model loaded from {MODEL_PATH}, labels: {_app_module.runner.labels}")
            # Sync frontend model_data.js with current model
            _generate_model_data_js(MODEL_PATH)
        except Exception as e:
            print(f"[WebEval] WARNING: Failed to load model: {e}")
    else:
        print("[WebEval] No existing model found. Train first before running inference.")

    print("[WebEval] Starting with extended routes (recording + training)")
    app.run(host="127.0.0.1", port=8787, debug=False)
